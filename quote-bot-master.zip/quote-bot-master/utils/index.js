const userName = require('./user-name')
const downloadFileByUrl = require('./download-file-by-url')

module.exports = {
  userName,
  downloadFileByUrl
}
