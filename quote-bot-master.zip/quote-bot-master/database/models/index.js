module.exports = {
  User: require('./user'),
  Group: require('./group'),
  Quote: require('./quote'),
  Stats: require('./stats'),
  Adv: require('./adv'),
  Invoice: require('./invoice')
}
